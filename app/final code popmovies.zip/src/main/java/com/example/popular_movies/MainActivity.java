package com.example.popular_movies;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.popular_movies.Adapters.GridViewAdapter;
import com.example.popular_movies.app.AppController;
import com.example.popular_movies.fragments.detailsFragmet;
import com.example.popular_movies.models.detailsModel;
import com.example.popular_movies.utils.Const;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;


public class MainActivity extends ActionBarActivity {

    private static final String TAG = "Volley";
    // Progress dialog
    private ProgressDialog pDialog;

    private ArrayList<detailsModel> DetailsList;

    static String sort_by;
    public static String Resolution;
    static int last_position = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        int screenOrientation = getResources().getConfiguration().orientation;

        if (screenOrientation == Configuration.ORIENTATION_PORTRAIT) {
            hideDetailsPane();
        }

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);

        makeJsonObjectRequest();
    }

    @Override
    protected void onResume() {
        super.onResume();

        SharedPreferences sharedPrefs =
                PreferenceManager.getDefaultSharedPreferences(this);
        String Resolution = sharedPrefs.getString(
                getString(R.string.pref_resolution_key),
                getString(R.string.pref_Res_high));

        String sortBy = sharedPrefs.getString(
                getString(R.string.pref_sortBy_key),
                getString(R.string.pref_sortBy_mostPopular));

        if(!sortBy.equals(this.sort_by)){
            last_position = 0;
            makeJsonObjectRequest();
        }else if(!Resolution.equals(this.Resolution)){
            makeJsonObjectRequest();
        }
    }

    /**
     * Method to hide the details pane
     */
    private void hideDetailsPane() {
        View alphaPane = findViewById(R.id.details);
        if (alphaPane.getVisibility() == View.VISIBLE) {
            alphaPane.setVisibility(View.GONE);
        }
    }

    /**
     * Method to show the details pane
     */
    private void showDetailsPane() {
        View alphaPane = findViewById(R.id.details);
        if (alphaPane.getVisibility() == View.GONE) {
            alphaPane.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showpDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hidepDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    void set_default_item_details(int position) {
        //to set the details for first item by default
        Bundle bundle = new Bundle();
        bundle.putString(Const.OMG_ID, DetailsList.get(position).getId());

        detailsFragmet fragment = new detailsFragmet();
        fragment.setArguments(bundle);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.details, fragment)
                .commit();
    }
    /**
     * Method to make json object request where json response starts wtih {
     */
    private void makeJsonObjectRequest() {

        showpDialog();

        SharedPreferences sharedPrefs =
                PreferenceManager.getDefaultSharedPreferences(this);
        String sortBy = sharedPrefs.getString(
                getString(R.string.pref_sortBy_key),
                getString(R.string.pref_sortBy_mostPopular));

        this.sort_by = sortBy;

        Uri builtUri = Uri.parse(Const.URL_API).buildUpon()
                .appendQueryParameter(Const.SORT_BY_TAG, sortBy)
                .appendQueryParameter(Const.KEY_API_TAG, Const.URL_API_KEY)
                .build();

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET,
                builtUri.toString(), null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                Log.d(TAG, response.toString());

                try {

                    DetailsList = new ArrayList<detailsModel>();
                    // Parsing json object response
                    JSONArray resultArray = response.getJSONArray(Const.OMG_RESULTS);
                    for (int i = 0; i < resultArray.length(); i++) {

                        JSONObject Object = resultArray.getJSONObject(i);
                        detailsModel temp = new detailsModel();
                        temp.setId(Object.getString(Const.OMG_ID));
                        temp.setPosterImage_url(Object.getString(Const.OMG_POSTER_PATH));

                        DetailsList.add(temp);
                    }

                    GridView gridview = (GridView) findViewById(R.id.gridview);
                    gridview.setAdapter(new GridViewAdapter(MainActivity.this, DetailsList));

                    gridview.setOnItemClickListener(new Listeners(getApplicationContext(), gridview));

                    gridview.setSelection(last_position);


                    set_default_item_details(last_position);


                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),
                            "Error: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                    Log.d(TAG, "Error: " + e.getMessage());
                }
                hidepDialog();
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Error Res: " + error.getMessage());
                // hide the progress dialog
                hidepDialog();
            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(jsonObjReq);
    }

    // listeners
    private class Listeners implements AdapterView.OnItemClickListener {

        private Context mContext;
        private GridView mgridview;

        public Listeners(Context context , GridView gridView) {
            mContext = context;
            mgridview = gridView;
        }

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//            Toast.makeText(MainActivity.this, "" + position,
//                    Toast.LENGTH_SHORT).show();

            MainActivity.last_position = position;

            mgridview.setSelected(true);
            mgridview.setSelection(position);
            mgridview.setItemChecked(position,true);

            int screenOrientation = getResources().getConfiguration().orientation;

            Bundle bundle = new Bundle();
            bundle.putString(Const.OMG_ID, DetailsList.get(position).getId());

            if (screenOrientation == Configuration.ORIENTATION_PORTRAIT) {
                startActivity(new Intent(mContext, ActivityDetails.class).putExtras(bundle));
            } else {
                detailsFragmet fragment = new detailsFragmet();
                fragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.details, fragment)
                        .commit();
            }
        }
    }
}
